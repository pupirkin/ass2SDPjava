package com.company;

import java.util.List;

public interface Observer {
    public void eventHandling(List<String> freeWindows);
}
